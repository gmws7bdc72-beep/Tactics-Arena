#!/usr/bin/env bash
set -euo pipefail
kit_dir="$(cd "$(dirname "$0")" && pwd)"
repo_root="$(git rev-parse --show-toplevel)"
target="$HOME/fta-defense-preview"
if [ -e "$target" ]; then
  echo "Preview folder already exists: $target. No files changed."
  exit 1
fi
if ! git -C "$repo_root" cat-file -e 2e02bb60cabec6e283a67a4902e9df0807c897d4^{commit}; then
  echo "The good-looking commit is missing. No files changed."
  exit 1
fi
git -C "$repo_root" worktree add --detach "$target" 2e02bb60cabec6e283a67a4902e9df0807c897d4
git -C "$target" apply --check "$kit_dir/defense.patch"
git -C "$target" apply "$kit_dir/defense.patch"
cp "$kit_dir/defense.test.ts" "$target/defense.test.ts"
echo "Ready for preview: $target"
echo "Your existing Replit workspace was not changed."
