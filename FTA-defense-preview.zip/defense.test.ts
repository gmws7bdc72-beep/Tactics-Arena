import assert from "node:assert/strict";
import {
  curvePointLimit,
  curvePointLimitForMechanic,
  planTacticalCurve,
  sampleChainedCurve,
  sanitizeCurvePoints,
} from "./artifacts/fta-game/src/engine/curve";
import { generateAICommands } from "./artifacts/fta-game/src/engine/ai";
import { runSimulation } from "./artifacts/fta-game/src/engine/simulation";
import {
  CommandType,
  GameEventType,
  PlayerState,
  type Command,
  type PlayerStats,
  type SimBall,
  type SimPlayer,
  type Vec2,
} from "./artifacts/fta-game/src/engine/types";
import { PITCH_HEIGHT, PITCH_WIDTH } from "./artifacts/fta-game/src/engine/constants";

const stats: PlayerStats = {
  attack: 8,
  defense: 7,
  passing: 9,
  speed: 10,
  movement: 9,
  shooting: 9,
  dribbling: 9,
  tackling: 7,
  marking: 7,
  stamina: 8,
  strength: 7,
  vision: 9,
  longPassing: 9,
  aerial: 8,
};

function player(
  id: string,
  teamId: "player" | "ai",
  position: Vec2,
  command: Command | null = null,
  overrides: Partial<PlayerStats> = {},
): SimPlayer {
  return {
    id,
    teamId,
    cardId: id,
    position: { ...position },
    startPosition: { ...position },
    velocity: { x: 0, y: 0 },
    state: PlayerState.IDLE,
    stats: { ...stats, ...overrides },
    ability: "none",
    command,
    commandExecuted: false,
    stateTimer: 0,
    recoveryTimer: 0,
    name: id,
    jerseyNumber: 1,
    role: "midfielder",
  };
}

function ownedBall(owner: SimPlayer): SimBall {
  return {
    position: { ...owner.position },
    velocity: { x: 0, y: 0 },
    ownerId: owner.id,
    height: 0,
  };
}


import { tileToPos } from "./artifacts/fta-game/src/engine/grid";
const attacker = player("attacker", "ai", tileToPos(7, 4));
const defender = player("defender", "player", tileToPos(5, 4), { type: CommandType.SLIDE, targetPosition: tileToPos(7, 4) });
const result = runSimulation([attacker, defender], ownedBall(attacker), 42);
assert.ok(result.events.some(event => event.type === GameEventType.LOOSE_BALL && event.playerId === defender.id), "contacting the carrier with a slide should produce a loose ball");
console.log("Slide tackle test passed");
{
  const movingAttacker = player("runner", "ai", tileToPos(7, 4), { type: CommandType.MOVE, targetPosition: tileToPos(9, 4) });
  const presser = player("presser", "player", tileToPos(5, 4), { type: CommandType.PRESS, targetPlayerId: "runner" });
  const press = runSimulation([movingAttacker, presser], ownedBall(movingAttacker), 42);
  assert.ok(press.frames.some(frame => frame.players.find(p => p.id === "presser")!.position.x > tileToPos(5, 4).x + 5), "presser should follow after its target moves");
}
{
  const stationary = player("stationary", "ai", tileToPos(7, 4));
  const presser = player("presser", "player", tileToPos(5, 4), { type: CommandType.PRESS, targetPlayerId: "stationary" });
  const press = runSimulation([stationary, presser], ownedBall(stationary), 42);
  assert.ok(press.frames.every(frame => Math.abs(frame.players.find(p => p.id === "presser")!.position.x - tileToPos(5, 4).x) < 1), "presser should not move if its target stays still");
}
console.log("Press tests passed");
{
  const carrier = player("carrier", "ai", tileToPos(7, 4));
  const tackler = player("tackler", "player", tileToPos(6, 4), { type: CommandType.STAND_TACKLE, targetPosition: tileToPos(7, 4) }, { tackling: 10, defense: 10 });
  const outcomes = Array.from({ length: 20 }, (_, seed) => runSimulation([carrier, tackler], ownedBall(carrier), (seed + 1) * 100000));
  assert.ok(outcomes.some(result => result.events.some(event => event.type === GameEventType.TACKLE && event.playerId === "tackler")), "standing tackle should be able to win a contested ball");
}
{
  const carrier = player("carrier", "ai", tileToPos(9, 4));
  const tackler = player("tackler", "player", tileToPos(5, 4), { type: CommandType.SLIDE, targetPosition: tileToPos(9, 4) });
  const result = runSimulation([carrier, tackler], ownedBall(carrier), 42);
  assert.ok(!result.events.some(event => event.type === GameEventType.LOOSE_BALL && event.playerId === "tackler"), "slide must not reach beyond its allowed range");
}
console.log("Standing and range tests passed");
