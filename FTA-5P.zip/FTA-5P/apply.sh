#!/usr/bin/env bash
set -euo pipefail

GAME="artifacts/fta-game"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -d "$GAME/src" ]; then
  echo "ERROR: Run this from ~/workspace."
  exit 1
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="backups/fta-5p-$STAMP"
FILES=(
  "src/game/nameDatabase.ts"
  "src/game/transferDatabase.ts"
  "src/game/persistence.ts"
  "src/game/league.ts"
  "src/engine/ai.ts"
  "src/pages/Match.tsx"
)

mkdir -p "$BACKUP"
: > "$BACKUP/.new-files"

for file in "${FILES[@]}"; do
  if [ -f "$GAME/$file" ]; then
    mkdir -p "$BACKUP/$(dirname "$file")"
    cp "$GAME/$file" "$BACKUP/$file"
  else
    echo "$file" >> "$BACKUP/.new-files"
  fi
done

rollback() {
  echo
  echo "Build failed. Restoring backup..."
  for file in "${FILES[@]}"; do
    if [ -f "$BACKUP/$file" ]; then
      mkdir -p "$GAME/$(dirname "$file")"
      cp "$BACKUP/$file" "$GAME/$file"
    fi
  done
  while IFS= read -r file; do
    [ -z "$file" ] || rm -f "$GAME/$file"
  done < "$BACKUP/.new-files"
  echo "Rollback complete: $BACKUP"
}
trap rollback ERR

cp -R "$SCRIPT_DIR/files/." "$GAME/"

cd "$GAME"
pnpm typecheck
pnpm build

trap - ERR
echo
echo "SUCCESS"
echo "Backup: $BACKUP"
