Run from ~/workspace:

unzip -o FTA-5P.zip
bash FTA-5P/apply.sh
