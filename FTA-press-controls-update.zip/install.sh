#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/workspace"
patch="$(cd "$(dirname "$0")" && pwd)/update.patch"
git apply --check "$patch" || { echo 'Update did not match the current files; nothing was changed. Install the previous FTA turn update first.'; exit 1; }
backup="$HOME/fta-before-press-update-$(date +%Y%m%d-%H%M%S).tar.gz"
tar -czf "$backup" artifacts/fta-game/src/engine/{simulation.ts,grid.ts} artifacts/fta-game/src/components/MechanicPad.tsx artifacts/fta-game/src/pages/{Match.tsx,OnlineMatch.tsx}
git apply "$patch"
echo "Update installed. Previous files saved at $backup"
