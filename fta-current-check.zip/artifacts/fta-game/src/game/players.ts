import type { PlayerCard, Ability, AbilityId, PlayerStats } from "../engine/types";

export const ABILITIES: Record<AbilityId, Ability> = {
  bullet_pass:  { id: "bullet_pass",  name: "Bullet Pass",  description: "Passes travel 50% faster and long-pass accuracy penalty halved" },
  iron_tackle:  { id: "iron_tackle",  name: "Iron Tackle",  description: "+20% tackle strength in physical duels" },
  ghost_run:    { id: "ghost_run",    name: "Ghost Run",    description: "Elusive runner — +15% dribble strength, reduced turning cost" },
  eagle_eye:    { id: "eagle_eye",    name: "Eagle Eye",    description: "+25% interception chance; shots travel 15% faster" },
  powerhouse:   { id: "powerhouse",   name: "Powerhouse",   description: "+20% duel and tackle strength" },
  shadow_mark:  { id: "shadow_mark",  name: "Shadow Mark",  description: "Slows a dribbling opponent on close contact" },
  goalkeeper:   { id: "goalkeeper",   name: "Goalkeeper",   description: "+35% save rate on shots and superior loose-ball control" },
  none:         { id: "none",         name: "No Ability",   description: "No special ability" },
};

export function createStats(stats: PlayerStats): PlayerStats {
  return stats;
}

export const STAT_LABELS: { key: keyof PlayerStats; label: string }[] = [
  { key: "attack", label: "ATK" },
  { key: "defense", label: "DEF" },
  { key: "passing", label: "PAS" },
  { key: "speed", label: "SPD" },
  { key: "shooting", label: "SHT" },
  { key: "dribbling", label: "DRB" },
  { key: "tackling", label: "TCK" },
  { key: "marking", label: "MRK" },
  { key: "stamina", label: "STA" },
  { key: "strength", label: "STR" },
  { key: "vision", label: "VIS" },
  { key: "longPassing", label: "LNG" },
  { key: "aerial", label: "AIR" },
  { key: "luck", label: "LCK" },
];

export const ALL_PLAYERS: PlayerCard[] = [
  // ── Goalkeepers ──────────────────────────────────────────────────────────
  { id: "gk_neuer",   name: "Neuer",   role: "goalkeeper", jerseyNumber: 1, ability: "goalkeeper", stats: createStats({ attack: 3, defense: 9, passing: 7, speed: 5, luck: 7, shooting: 2, dribbling: 4, tackling: 5, marking: 8, stamina: 7, strength: 8, vision: 7, longPassing: 8, aerial: 9 }) },
  { id: "gk_alisson", name: "Alisson", role: "goalkeeper", jerseyNumber: 1, ability: "goalkeeper", stats: createStats({ attack: 2, defense: 10, passing: 6, speed: 5, luck: 8, shooting: 2, dribbling: 4, tackling: 5, marking: 9, stamina: 8, strength: 8, vision: 6, longPassing: 7, aerial: 10 }) },
  { id: "gk_ederson", name: "Ederson", role: "goalkeeper", jerseyNumber: 1, ability: "goalkeeper", stats: createStats({ attack: 4, defense: 8, passing: 9, speed: 5, luck: 6, shooting: 3, dribbling: 5, tackling: 4, marking: 7, stamina: 7, strength: 7, vision: 9, longPassing: 10, aerial: 8 }) },

  // ── Defenders ─────────────────────────────────────────────────────────────
  { id: "p4",  name: "Alaba",   role: "defender", jerseyNumber: 5,  ability: "shadow_mark", stats: createStats({ attack: 5, defense: 8, passing: 8, speed: 6, luck: 6, shooting: 5, dribbling: 6, tackling: 8, marking: 8, stamina: 8, strength: 7, vision: 8, longPassing: 8, aerial: 7 }) },
  { id: "p7",  name: "Dias",    role: "defender", jerseyNumber: 3,  ability: "iron_tackle", stats: createStats({ attack: 3, defense: 10, passing: 6, speed: 5, luck: 5, shooting: 3, dribbling: 4, tackling: 10, marking: 10, stamina: 8, strength: 10, vision: 6, longPassing: 6, aerial: 10 }) },
  { id: "p10", name: "Walker",  role: "defender", jerseyNumber: 2,  ability: "ghost_run", stats: createStats({ attack: 5, defense: 8, passing: 6, speed: 10, luck: 5, shooting: 4, dribbling: 7, tackling: 8, marking: 8, stamina: 9, strength: 8, vision: 6, longPassing: 7, aerial: 7 }) },
  { id: "p12", name: "Rudiger", role: "defender", jerseyNumber: 22, ability: "shadow_mark", stats: createStats({ attack: 4, defense: 10, passing: 5, speed: 7, luck: 4, shooting: 4, dribbling: 5, tackling: 10, marking: 9, stamina: 8, strength: 10, vision: 5, longPassing: 6, aerial: 9 }) },

  // ── Midfielders ───────────────────────────────────────────────────────────
  { id: "p3",  name: "Kante",      role: "midfielder", jerseyNumber: 6,  ability: "iron_tackle", stats: createStats({ attack: 6, defense: 9, passing: 7, speed: 8, luck: 5, shooting: 5, dribbling: 7, tackling: 10, marking: 9, stamina: 10, strength: 7, vision: 7, longPassing: 6, aerial: 5 }) },
  { id: "p6",  name: "Modric",     role: "midfielder", jerseyNumber: 8,  ability: "bullet_pass", stats: createStats({ attack: 7, defense: 7, passing: 10, speed: 7, luck: 9, shooting: 7, dribbling: 9, tackling: 7, marking: 7, stamina: 8, strength: 5, vision: 10, longPassing: 9, aerial: 4 }) },
  { id: "p9",  name: "Bellingham", role: "midfielder", jerseyNumber: 22, ability: "powerhouse", stats: createStats({ attack: 9, defense: 8, passing: 8, speed: 8, luck: 8, shooting: 8, dribbling: 8, tackling: 8, marking: 8, stamina: 10, strength: 9, vision: 8, longPassing: 8, aerial: 8 }) },
  { id: "p11", name: "Pedri",      role: "midfielder", jerseyNumber: 8,  ability: "bullet_pass", stats: createStats({ attack: 7, defense: 6, passing: 10, speed: 7, luck: 9, shooting: 6, dribbling: 9, tackling: 6, marking: 7, stamina: 8, strength: 5, vision: 10, longPassing: 8, aerial: 3 }) },

  // ── Forwards / Strikers ───────────────────────────────────────────────────
  { id: "p1", name: "Kane",     role: "striker", jerseyNumber: 9,  ability: "eagle_eye", stats: createStats({ attack: 10, defense: 4, passing: 8, speed: 7, luck: 6, shooting: 10, dribbling: 7, tackling: 4, marking: 5, stamina: 8, strength: 8, vision: 9, longPassing: 8, aerial: 9 }) },
  { id: "p2", name: "Muller",   role: "forward", jerseyNumber: 10, ability: "bullet_pass", stats: createStats({ attack: 8, defense: 5, passing: 9, speed: 7, luck: 8, shooting: 8, dribbling: 7, tackling: 5, marking: 6, stamina: 8, strength: 6, vision: 10, longPassing: 8, aerial: 6 }) },
  { id: "p5", name: "Vinicius", role: "forward", jerseyNumber: 7,  ability: "ghost_run", stats: createStats({ attack: 9, defense: 3, passing: 7, speed: 10, luck: 7, shooting: 8, dribbling: 10, tackling: 3, marking: 4, stamina: 8, strength: 6, vision: 7, longPassing: 6, aerial: 5 }) },
  { id: "p8", name: "Mbappe",   role: "striker", jerseyNumber: 10, ability: "ghost_run", stats: createStats({ attack: 10, defense: 3, passing: 7, speed: 10, luck: 7, shooting: 10, dribbling: 9, tackling: 3, marking: 4, stamina: 9, strength: 8, vision: 8, longPassing: 7, aerial: 7 }) },
];

export function getDefaultSquad(): PlayerCard[] {
  return [
    ALL_PLAYERS.find(p => p.id === "gk_neuer")!,
    ALL_PLAYERS.find(p => p.id === "p4")!,
    ALL_PLAYERS.find(p => p.id === "p3")!,
    ALL_PLAYERS.find(p => p.id === "p5")!,
    ALL_PLAYERS.find(p => p.id === "p1")!,
  ];
}

export function getGoalkeepers(): PlayerCard[] {
  return ALL_PLAYERS.filter(p => p.role === "goalkeeper");
}

export function getOutfieldPlayers(): PlayerCard[] {
  return ALL_PLAYERS.filter(p => p.role !== "goalkeeper");
}
