#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
if [[ ! -d "$ROOT/artifacts/fta-game" ]]; then
  echo "Run this from your Replit workspace root (the folder containing artifacts/fta-game)."
  exit 1
fi

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP="$(mktemp -d)"
FILES=(
  "artifacts/fta-game/src/components/PitchCanvas.tsx"
  "artifacts/fta-game/src/pages/OnlineMatch.tsx"
)

rollback() {
  echo "❌ Validation failed — restoring the previous files."
  for file in "${FILES[@]}"; do
    if [[ -f "$BACKUP/$file" ]]; then
      mkdir -p "$ROOT/$(dirname "$file")"
      cp "$BACKUP/$file" "$ROOT/$file"
    fi
  done
}
trap rollback ERR

for file in "${FILES[@]}"; do
  mkdir -p "$BACKUP/$(dirname "$file")"
  cp "$ROOT/$file" "$BACKUP/$file"
done

python3 "$PATCH_DIR/patch.py"

cd "$ROOT/artifacts/fta-game"
echo "→ Typecheck"
pnpm typecheck
echo "→ Build"
pnpm build

trap - ERR
rm -rf "$BACKUP"
echo "✅ FTA-A16 applied successfully."
