#!/usr/bin/env bash
set -euo pipefail
kit_dir="$(cd "$(dirname "$0")" && pwd)"
cd "$(git rev-parse --show-toplevel)"
if ! git apply --check "$kit_dir/defense-update.patch"; then
  echo "The game files differ from the expected version. Nothing was changed."
  exit 1
fi
backup="$HOME/fta-before-oop-$(date +%Y%m%d-%H%M%S).tar.gz"
tar -czf "$backup" \
  artifacts/fta-game/src/components/MechanicPad.tsx \
  artifacts/fta-game/src/components/PitchCanvas.tsx \
  artifacts/fta-game/src/engine/ai.ts \
  artifacts/fta-game/src/engine/constants.ts \
  artifacts/fta-game/src/engine/grid.ts \
  artifacts/fta-game/src/pages/Match.tsx \
  artifacts/fta-game/src/pages/OnlineMatch.tsx
git apply "$kit_dir/defense-update.patch"
echo "Defense update applied. Backup: $backup"
echo "You can now Run and republish the game."
