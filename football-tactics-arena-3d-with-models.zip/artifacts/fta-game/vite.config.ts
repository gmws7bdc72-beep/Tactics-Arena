import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  plugins: [react(), tailwindcss()],

  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
      "@assets": path.resolve(__dirname, "..", "..", "attached_assets"),
    },
    dedupe: ["react", "react-dom"],
  },

  server: {
    host: "0.0.0.0",
    strictPort: false,
    allowedHosts: true,
  },

  preview: {
    host: "0.0.0.0",
    strictPort: false,
    allowedHosts: true,
  },

  build: {
    outDir: "dist",
    emptyOutDir: true,
  },
});
