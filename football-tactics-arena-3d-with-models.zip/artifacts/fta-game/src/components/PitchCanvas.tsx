import { useRef, useEffect, useCallback } from "react";
import type { MouseEvent } from "react";
import type { FrameSnapshot, TeamConfig, Vec2, Command } from "../engine/types";
import { CommandType } from "../engine/types";
import {
  PITCH_WIDTH,
  PITCH_HEIGHT,
  GOAL_WIDTH,
  GOAL_DEPTH,
  GOAL_TOP_Y,
  PENALTY_AREA_WIDTH,
  PENALTY_AREA_HEIGHT,
  PLAYER_RADIUS,
  BALL_RADIUS,
  TILE_W,
  TILE_H,
  GRID_COLS,
  GRID_ROWS,
} from "../engine/constants";
import { posToTile, getReachableTiles, tileToPos } from "../engine/grid";

interface Props {
  frame: FrameSnapshot | null;
  playerTeam: TeamConfig;
  aiTeamColor?: string;
  aiTeamSecondaryColor?: string;
  pendingCommands: Map<string, Command>;
  selectedPlayerId: string | null;
  passTargetMode: boolean;
  passOriginPos?: Vec2;
  phase: "planning" | "simulating" | "finished";
  isVertical?: boolean;
  activePlanningTeam?: "player" | "ai";
  onPlayerClick: (playerId: string, pos: Vec2) => void;
  onTileClick: (pos: Vec2, isEnemyTile: boolean) => void;
}

type TileState = "reachable" | "reachable-enemy" | "reachable-friendly" | "current" | "none";
type ScreenPoint = { x: number; y: number };
type View2_5D = {
  project: (p: Vec2) => ScreenPoint;
  unproject: (p: ScreenPoint) => Vec2;
  radius: (r: number, pitchY?: number) => number;
  depth: (p: Vec2) => number;
  base: (p: Vec2) => ScreenPoint;
};

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

function rgba(hex: string, alpha: number): string {
  const clean = hex.replace("#", "");
  const bigint = parseInt(clean.length === 3 ? clean.split("").map((c) => c + c).join("") : clean, 16);
  const r = (bigint >> 16) & 255;
  const g = (bigint >> 8) & 255;
  const b = bigint & 255;
  return `rgba(${r},${g},${b},${alpha})`;
}

function createView(W: number, H: number, isVertical: boolean): View2_5D {
  const baseW = isVertical ? PITCH_HEIGHT : PITCH_WIDTH;
  const baseH = isVertical ? PITCH_WIDTH : PITCH_HEIGHT;
  const skew = 0.28;
  const squash = 0.72;

  const base = (p: Vec2): ScreenPoint =>
    isVertical
      ? { x: p.y, y: PITCH_WIDTH - p.x }
      : { x: p.x, y: p.y };

  const raw = (p: Vec2): ScreenPoint => {
    const b = base(p);
    return {
      x: b.x - (b.y - baseH / 2) * skew,
      y: b.y * squash,
    };
  };

  const corners = [
    raw({ x: 0, y: 0 }),
    raw({ x: PITCH_WIDTH, y: 0 }),
    raw({ x: PITCH_WIDTH, y: PITCH_HEIGHT }),
    raw({ x: 0, y: PITCH_HEIGHT }),
  ];

  const minX = Math.min(...corners.map((p) => p.x));
  const maxX = Math.max(...corners.map((p) => p.x));
  const minY = Math.min(...corners.map((p) => p.y));
  const maxY = Math.max(...corners.map((p) => p.y));

  const padX = W * 0.04;
  const padTop = H * 0.06;
  const padBottom = H * 0.07;
  const scale = Math.min((W - padX * 2) / (maxX - minX), (H - padTop - padBottom) / (maxY - minY));
  const ox = (W - (maxX - minX) * scale) / 2 - minX * scale;
  const oy = padTop - minY * scale;

  const project = (p: Vec2): ScreenPoint => {
    const r = raw(p);
    return { x: ox + r.x * scale, y: oy + r.y * scale };
  };

  const unproject = (s: ScreenPoint): Vec2 => {
    const rx = (s.x - ox) / scale;
    const ry = (s.y - oy) / scale;
    const by = ry / squash;
    const bx = rx + (by - baseH / 2) * skew;

    const pitch = isVertical
      ? { x: PITCH_WIDTH - by, y: bx }
      : { x: bx, y: by };

    return {
      x: clamp(pitch.x, 0, PITCH_WIDTH - 1),
      y: clamp(pitch.y, 0, PITCH_HEIGHT - 1),
    };
  };

  const depth = (p: Vec2) => {
    const b = base(p);
    return clamp(b.y / baseH, 0, 1);
  };

  const radius = (r: number, pitchY = PITCH_HEIGHT / 2) => {
    const fakeDepth = isVertical ? 0.5 : clamp(pitchY / PITCH_HEIGHT, 0, 1);
    return r * scale * (0.82 + fakeDepth * 0.24);
  };

  return { project, unproject, radius, depth, base };
}

function drawPoly(ctx: CanvasRenderingContext2D, points: ScreenPoint[], fill?: string, stroke?: string, lineWidth = 1) {
  if (points.length === 0) return;
  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) ctx.lineTo(points[i].x, points[i].y);
  ctx.closePath();
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = lineWidth;
    ctx.stroke();
  }
}

function drawProjectedLine(ctx: CanvasRenderingContext2D, view: View2_5D, a: Vec2, b: Vec2, stroke: string, width = 2, dash?: number[]) {
  const p1 = view.project(a);
  const p2 = view.project(b);
  ctx.save();
  if (dash) ctx.setLineDash(dash);
  ctx.strokeStyle = stroke;
  ctx.lineWidth = width;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  ctx.stroke();
  ctx.restore();
}

function drawProjectedPath(ctx: CanvasRenderingContext2D, view: View2_5D, points: Vec2[], stroke: string, width = 2, close = false) {
  if (points.length === 0) return;
  const first = view.project(points[0]);
  ctx.beginPath();
  ctx.moveTo(first.x, first.y);
  for (let i = 1; i < points.length; i++) {
    const p = view.project(points[i]);
    ctx.lineTo(p.x, p.y);
  }
  if (close) ctx.closePath();
  ctx.strokeStyle = stroke;
  ctx.lineWidth = width;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.stroke();
}

function circlePoints(center: Vec2, radius: number, start = 0, end = Math.PI * 2, steps = 56): Vec2[] {
  const pts: Vec2[] = [];
  const total = Math.max(8, steps);
  for (let i = 0; i <= total; i++) {
    const t = start + ((end - start) * i) / total;
    pts.push({ x: center.x + Math.cos(t) * radius, y: center.y + Math.sin(t) * radius });
  }
  return pts;
}

function tileCorners(col: number, row: number): Vec2[] {
  const x = col * TILE_W;
  const y = row * TILE_H;
  return [
    { x, y },
    { x: x + TILE_W, y },
    { x: x + TILE_W, y: y + TILE_H },
    { x, y: y + TILE_H },
  ];
}



export default function PitchCanvas({
  frame,
  playerTeam,
  aiTeamColor = "#e53935",
  aiTeamSecondaryColor = "#ffffff",
  pendingCommands,
  selectedPlayerId,
  passTargetMode,
  passOriginPos,
  phase,
  isVertical = false,
  activePlanningTeam,
  onPlayerClick,
  onTileClick,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const canvasToPitch = useCallback((cx: number, cy: number): Vec2 => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const sx = ((cx - rect.left) / rect.width) * canvas.width;
    const sy = ((cy - rect.top) / rect.height) * canvas.height;
    return createView(canvas.width, canvas.height, isVertical).unproject({ x: sx, y: sy });
  }, [isVertical]);

  const buildTileMap = useCallback((): Map<string, TileState> => {
    const map = new Map<string, TileState>();
    if (!frame || !selectedPlayerId) return map;
    if (passTargetMode) return map;

    const selPlayer = frame.players.find((p) => p.id === selectedPlayerId);
    if (!selPlayer) return map;

    const pt = posToTile(selPlayer.position);
    const isGK = selPlayer.role === "goalkeeper";
    const range = selPlayer.tileRange;

    map.set(`${pt.col},${pt.row}`, "current");

    const occupancy = new Map<string, "friendly" | "enemy">();
    for (const p of frame.players) {
      if (p.id === selectedPlayerId) continue;
      const t = posToTile(p.position);
      occupancy.set(`${t.col},${t.row}`, p.teamId === selPlayer.teamId ? "friendly" : "enemy");
    }

    const reachable = getReachableTiles(pt.col, pt.row, range, isGK, selPlayer.teamId);
    for (const t of reachable) {
      const key = `${t.col},${t.row}`;
      const occ = occupancy.get(key);
      if (occ === "friendly") map.set(key, "reachable-friendly");
      else if (occ === "enemy") map.set(key, "reachable-enemy");
      else map.set(key, "reachable");
    }

    return map;
  }, [frame, selectedPlayerId, passTargetMode]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !frame) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    const view = createView(W, H, isVertical);

    ctx.clearRect(0, 0, W, H);

    // Background / arena outside the pitch.
    const bg = ctx.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, "#08111d");
    bg.addColorStop(0.55, "#12251d");
    bg.addColorStop(1, "#070b10");
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    // Soft vignette.
    const vignette = ctx.createRadialGradient(W / 2, H * 0.45, W * 0.05, W / 2, H * 0.55, W * 0.75);
    vignette.addColorStop(0, "rgba(255,255,255,0.05)");
    vignette.addColorStop(1, "rgba(0,0,0,0.42)");
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, W, H);

    const pitchCorners = [
      view.project({ x: 0, y: 0 }),
      view.project({ x: PITCH_WIDTH, y: 0 }),
      view.project({ x: PITCH_WIDTH, y: PITCH_HEIGHT }),
      view.project({ x: 0, y: PITCH_HEIGHT }),
    ];

    // Concrete border behind the pitch.
    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,0.85)";
    ctx.shadowBlur = 26;
    ctx.shadowOffsetY = 18;
    drawPoly(ctx, pitchCorners, "#243d2b", "rgba(255,255,255,0.15)", 2);
    ctx.restore();

    // Pitch base.
    const pitchGrad = ctx.createLinearGradient(0, pitchCorners[0].y, 0, pitchCorners[2].y);
    pitchGrad.addColorStop(0, "#416e31");
    pitchGrad.addColorStop(0.5, "#547f36");
    pitchGrad.addColorStop(1, "#355a29");
    drawPoly(ctx, pitchCorners, pitchGrad, "rgba(255,255,255,0.28)", 2.2);

    // Alternating grass strips, projected into perspective.
    for (let col = 0; col < GRID_COLS; col++) {
      const fill = col % 2 === 0 ? "rgba(255,255,255,0.045)" : "rgba(0,0,0,0.035)";
      const x1 = col * TILE_W;
      const x2 = x1 + TILE_W;
      drawPoly(
        ctx,
        [
          view.project({ x: x1, y: 0 }),
          view.project({ x: x2, y: 0 }),
          view.project({ x: x2, y: PITCH_HEIGHT }),
          view.project({ x: x1, y: PITCH_HEIGHT }),
        ],
        fill,
      );
    }

    // Tiny dirt/noise speckles. Deterministic pattern.
    ctx.save();
    ctx.globalAlpha = 0.13;
    for (let i = 0; i < 150; i++) {
      const rx = (i * 193) % Math.floor(PITCH_WIDTH);
      const ry = (i * 97) % Math.floor(PITCH_HEIGHT);
      const p = view.project({ x: rx, y: ry });
      ctx.fillStyle = i % 3 === 0 ? "rgba(255,230,165,0.35)" : "rgba(30,20,10,0.28)";
      ctx.fillRect(p.x, p.y, 1.1, 1.1);
    }
    ctx.restore();

    // Main field lines.
    const line = "rgba(255,255,255,0.78)";
    drawProjectedPath(
      ctx,
      view,
      [
        { x: 0, y: 0 },
        { x: PITCH_WIDTH, y: 0 },
        { x: PITCH_WIDTH, y: PITCH_HEIGHT },
        { x: 0, y: PITCH_HEIGHT },
      ],
      line,
      2.2,
      true,
    );
    drawProjectedLine(ctx, view, { x: PITCH_WIDTH / 2, y: 0 }, { x: PITCH_WIDTH / 2, y: PITCH_HEIGHT }, line, 2);
    drawProjectedPath(ctx, view, circlePoints({ x: PITCH_WIDTH / 2, y: PITCH_HEIGHT / 2 }, 55), line, 1.8);

    const paY = (PITCH_HEIGHT - PENALTY_AREA_HEIGHT) / 2;
    const leftPA = [
      { x: 0, y: paY },
      { x: PENALTY_AREA_WIDTH, y: paY },
      { x: PENALTY_AREA_WIDTH, y: paY + PENALTY_AREA_HEIGHT },
      { x: 0, y: paY + PENALTY_AREA_HEIGHT },
    ];
    const rightPA = [
      { x: PITCH_WIDTH, y: paY },
      { x: PITCH_WIDTH - PENALTY_AREA_WIDTH, y: paY },
      { x: PITCH_WIDTH - PENALTY_AREA_WIDTH, y: paY + PENALTY_AREA_HEIGHT },
      { x: PITCH_WIDTH, y: paY + PENALTY_AREA_HEIGHT },
    ];
    drawProjectedPath(ctx, view, leftPA, line, 2, false);
    drawProjectedPath(ctx, view, rightPA, line, 2, false);

    const goalTop = GOAL_TOP_Y;
    const goalBottom = GOAL_TOP_Y + GOAL_WIDTH;
    drawProjectedPath(
      ctx,
      view,
      [
        { x: 0, y: goalTop },
        { x: -GOAL_DEPTH, y: goalTop },
        { x: -GOAL_DEPTH, y: goalBottom },
        { x: 0, y: goalBottom },
      ],
      "rgba(255,255,255,0.72)",
      2.4,
    );
    drawProjectedPath(
      ctx,
      view,
      [
        { x: PITCH_WIDTH, y: goalTop },
        { x: PITCH_WIDTH + GOAL_DEPTH, y: goalTop },
        { x: PITCH_WIDTH + GOAL_DEPTH, y: goalBottom },
        { x: PITCH_WIDTH, y: goalBottom },
      ],
      "rgba(255,255,255,0.72)",
      2.4,
    );

    // Offside thirds as subtle shaded panels.
    ctx.save();
    ctx.globalAlpha = 0.08;
    drawPoly(
      ctx,
      [
        view.project({ x: 0, y: 0 }),
        view.project({ x: PITCH_WIDTH / 3, y: 0 }),
        view.project({ x: PITCH_WIDTH / 3, y: PITCH_HEIGHT }),
        view.project({ x: 0, y: PITCH_HEIGHT }),
      ],
      "#ffffff",
    );
    drawPoly(
      ctx,
      [
        view.project({ x: (2 * PITCH_WIDTH) / 3, y: 0 }),
        view.project({ x: PITCH_WIDTH, y: 0 }),
        view.project({ x: PITCH_WIDTH, y: PITCH_HEIGHT }),
        view.project({ x: (2 * PITCH_WIDTH) / 3, y: PITCH_HEIGHT }),
      ],
      "#ffffff",
    );
    ctx.restore();
    drawProjectedLine(ctx, view, { x: PITCH_WIDTH / 3, y: 0 }, { x: PITCH_WIDTH / 3, y: PITCH_HEIGHT }, "rgba(255,255,255,0.35)", 1.2, [7, 5]);
    drawProjectedLine(ctx, view, { x: (2 * PITCH_WIDTH) / 3, y: 0 }, { x: (2 * PITCH_WIDTH) / 3, y: PITCH_HEIGHT }, "rgba(255,255,255,0.35)", 1.2, [7, 5]);

    // Tile grid / highlights.
    const selPlayer = selectedPlayerId ? frame.players.find((p) => p.id === selectedPlayerId) : null;
    const tileMap = phase === "planning" ? buildTileMap() : new Map<string, TileState>();
    if (phase === "planning") {
      for (let col = 0; col < GRID_COLS; col++) {
        for (let row = 0; row < GRID_ROWS; row++) {
          const key = `${col},${row}`;
          const state = tileMap.get(key) ?? "none";
          const corners = tileCorners(col, row).map(view.project);

          if (selPlayer && state === "current") {
            drawPoly(ctx, corners, "rgba(255,220,0,0.25)", "rgba(255,220,0,0.75)", 1.3);
          } else if (selPlayer && state === "reachable") {
            drawPoly(ctx, corners, "rgba(0,230,118,0.16)", "rgba(0,230,118,0.45)", 1.1);
          } else if (selPlayer && state === "reachable-enemy") {
            drawPoly(ctx, corners, "rgba(255,96,0,0.22)", "rgba(255,96,0,0.65)", 1.2);
          } else if (selPlayer && state === "reachable-friendly") {
            drawPoly(ctx, corners, "rgba(120,120,120,0.12)", "rgba(180,180,180,0.32)", 1.0);
          } else {
            drawPoly(ctx, corners, undefined, "rgba(255,255,255,0.055)", 0.6);
          }
        }
      }
    }

    // Pending command arrows.
    if (phase === "planning") {
      pendingCommands.forEach((cmd, playerId) => {
        const pf = frame.players.find((p) => p.id === playerId);
        if (!pf) return;
        const from = view.project(pf.position);

        const drawArrow = (fromPos: ScreenPoint, toPitch: Vec2, color: string, dashed = true, arc = false) => {
          const to = view.project(toPitch);
          ctx.save();
          ctx.globalAlpha = 0.82;
          ctx.strokeStyle = color;
          ctx.fillStyle = color;
          ctx.lineWidth = arc ? 4 : 3;
          ctx.lineCap = "round";
          if (dashed) ctx.setLineDash(arc ? [13, 8] : [8, 6]);
          ctx.beginPath();
          if (arc) {
            const mid = { x: (fromPos.x + to.x) / 2, y: Math.min(fromPos.y, to.y) - Math.abs(to.x - fromPos.x) * 0.18 - 38 };
            ctx.moveTo(fromPos.x, fromPos.y);
            ctx.quadraticCurveTo(mid.x, mid.y, to.x, to.y);
          } else {
            ctx.moveTo(fromPos.x, fromPos.y);
            ctx.lineTo(to.x, to.y);
          }
          ctx.stroke();
          ctx.setLineDash([]);
          const ang = Math.atan2(to.y - fromPos.y, to.x - fromPos.x);
          ctx.beginPath();
          ctx.moveTo(to.x, to.y);
          ctx.lineTo(to.x - Math.cos(ang - 0.5) * 14, to.y - Math.sin(ang - 0.5) * 14);
          ctx.lineTo(to.x - Math.cos(ang + 0.5) * 14, to.y - Math.sin(ang + 0.5) * 14);
          ctx.closePath();
          ctx.fill();
          ctx.restore();
        };

        if (cmd.type === CommandType.MOVE && cmd.targetPosition) {
          drawArrow(from, cmd.targetPosition, "#00e676", true, false);
          const to = view.project(cmd.targetPosition);
          if (cmd.followUp?.type === CommandType.PASS && cmd.followUp.targetPosition) {
            drawArrow(to, cmd.followUp.targetPosition, "#ff1744", true, true);
          }
        } else if (cmd.type === CommandType.PASS && cmd.targetPosition) {
          drawArrow(from, cmd.targetPosition, "#ffeb3b", true, true);
          if (cmd.followUp?.type === CommandType.MOVE && cmd.followUp.targetPosition) {
            drawArrow(from, cmd.followUp.targetPosition, "#ff9800", true, false);
          }
        } else if (cmd.type === CommandType.SHOOT) {
          drawArrow(from, { x: pf.teamId === "player" ? PITCH_WIDTH : 0, y: PITCH_HEIGHT / 2 }, "#ff6b35", true, true);
        }
      });
    }

    // Draw players sorted by visual depth so lower players overlap correctly.
    const players = [...frame.players].sort((a, b) => view.project(a.position).y - view.project(b.position).y);

    for (const p of players) {
      const pos = view.project(p.position);
      const isPlayerTeam = p.teamId === "player";
      const isSelected = p.id === selectedPlayerId;
      const isGK = p.role === "goalkeeper";
      const depth = view.depth(p.position);
      const scale = 0.78 + depth * 0.33;

      const baseColor = isPlayerTeam ? playerTeam.jerseyColor : aiTeamColor;
      const secColor = isPlayerTeam ? playerTeam.secondaryColor : aiTeamSecondaryColor;
      const ringColor = isSelected ? "#00e5ff" : frame.ball.ownerId === p.id ? "#ffd700" : rgba(baseColor, 0.9);
      const r = view.radius(isGK ? PLAYER_RADIUS + 3 : PLAYER_RADIUS, p.position.y);
      const bodyH = r * (1.9 + scale * 0.25);
      const bodyW = r * 1.05;
      const headR = r * 0.42;

      // Shadow.
      ctx.save();
      ctx.globalAlpha = 0.32;
      ctx.fillStyle = "#000000";
      ctx.beginPath();
      ctx.ellipse(pos.x + r * 0.14, pos.y + r * 0.82, r * 1.15, r * 0.38, -0.12, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Selection / possession ring.
      ctx.save();
      ctx.strokeStyle = ringColor;
      ctx.lineWidth = isSelected ? 4 : 2.4;
      ctx.shadowColor = ringColor;
      ctx.shadowBlur = isSelected || frame.ball.ownerId === p.id ? 15 : 4;
      ctx.beginPath();
      ctx.ellipse(pos.x, pos.y + r * 0.7, r * 1.18, r * 0.45, -0.08, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // Legs.
      ctx.save();
      ctx.strokeStyle = "#171717";
      ctx.lineWidth = Math.max(3, r * 0.22);
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(pos.x - bodyW * 0.22, pos.y + r * 0.45);
      ctx.lineTo(pos.x - bodyW * 0.48, pos.y + r * 0.95);
      ctx.moveTo(pos.x + bodyW * 0.22, pos.y + r * 0.45);
      ctx.lineTo(pos.x + bodyW * 0.42, pos.y + r * 0.98);
      ctx.stroke();
      ctx.strokeStyle = secColor;
      ctx.lineWidth = Math.max(2, r * 0.12);
      ctx.beginPath();
      ctx.moveTo(pos.x - bodyW * 0.48, pos.y + r * 0.95);
      ctx.lineTo(pos.x - bodyW * 0.72, pos.y + r * 1.0);
      ctx.moveTo(pos.x + bodyW * 0.42, pos.y + r * 0.98);
      ctx.lineTo(pos.x + bodyW * 0.66, pos.y + r * 1.0);
      ctx.stroke();
      ctx.restore();

      // Body.
      const torsoY = pos.y - bodyH * 0.32;
      const jerseyGrad = ctx.createLinearGradient(pos.x - bodyW, torsoY, pos.x + bodyW, torsoY + bodyH);
      jerseyGrad.addColorStop(0, rgba("#ffffff", 0.18));
      jerseyGrad.addColorStop(0.25, baseColor);
      jerseyGrad.addColorStop(1, rgba(baseColor, 0.78));
      ctx.save();
      ctx.fillStyle = jerseyGrad;
      ctx.strokeStyle = isGK ? "#ffd700" : "rgba(0,0,0,0.55)";
      ctx.lineWidth = isGK ? 2.4 : 1.4;
      ctx.beginPath();
      ctx.roundRect(pos.x - bodyW / 2, torsoY, bodyW, bodyH * 0.58, r * 0.2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();

      // Arms.
      ctx.save();
      ctx.strokeStyle = baseColor;
      ctx.lineWidth = Math.max(3, r * 0.2);
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(pos.x - bodyW * 0.46, torsoY + bodyH * 0.12);
      ctx.lineTo(pos.x - bodyW * 0.76, torsoY + bodyH * 0.38);
      ctx.moveTo(pos.x + bodyW * 0.46, torsoY + bodyH * 0.12);
      ctx.lineTo(pos.x + bodyW * 0.75, torsoY + bodyH * 0.36);
      ctx.stroke();
      ctx.restore();

      // Head + hair.
      ctx.save();
      ctx.fillStyle = "#c98b4c";
      ctx.strokeStyle = "rgba(0,0,0,0.45)";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(pos.x, torsoY - headR * 0.72, headR, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#1b1714";
      ctx.beginPath();
      ctx.ellipse(pos.x, torsoY - headR * 1.02, headR * 0.85, headR * 0.35, 0, Math.PI, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Jersey number.
      ctx.fillStyle = secColor;
      ctx.font = `900 ${Math.round(r * 0.55)}px 'Inter', sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(String(p.jerseyNumber), pos.x, torsoY + bodyH * 0.28);

      // Name tag.
      const nameW = clamp(r * 3.3, 28, 54);
      const nameH = clamp(r * 0.7, 8, 13);
      ctx.save();
      ctx.fillStyle = "rgba(0,0,0,0.72)";
      ctx.beginPath();
      ctx.roundRect(pos.x - nameW / 2, torsoY - headR * 2.25, nameW, nameH, 4);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.font = `700 ${Math.round(nameH * 0.55)}px 'Inter', sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(p.name.slice(0, 10), pos.x, torsoY - headR * 2.25 + nameH / 2);
      ctx.restore();

      if (p.offside) {
        ctx.save();
        const fw = r * 1.1;
        const fh = r * 0.62;
        ctx.fillStyle = "#ff1744";
        ctx.fillRect(pos.x + r * 0.78, torsoY - headR * 2.2, fw, fh);
        ctx.fillStyle = "#fff";
        ctx.font = `900 ${Math.round(fh * 0.55)}px 'Inter', sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("OS", pos.x + r * 0.78 + fw / 2, torsoY - headR * 2.2 + fh / 2);
        ctx.restore();
      }
    }

    // Ball drawn last-ish so it pops.
    const ballGround = view.project(frame.ball.position);
    const bv = frame.ball.velocity;
    const spd = Math.sqrt(bv.x * bv.x + bv.y * bv.y);
    const ballHeight = frame.ball.height ?? 0;
    const lift = view.radius(ballHeight * 1.15, frame.ball.position.y);
    const ballPos = { x: ballGround.x, y: ballGround.y - lift };
    const isLongBall = frame.ball.passStyle === "long" && ballHeight > 1;
    const br = view.radius(isLongBall ? BALL_RADIUS * 1.18 : BALL_RADIUS, frame.ball.position.y);

    if (phase === "simulating" && spd > 25) {
      const trailGround = view.project({
        x: frame.ball.position.x - bv.x * 0.08,
        y: frame.ball.position.y - bv.y * 0.08,
      });
      ctx.save();
      ctx.globalAlpha = 0.85;
      const grad = ctx.createLinearGradient(trailGround.x, trailGround.y, ballPos.x, ballPos.y);
      grad.addColorStop(0, "rgba(255,255,255,0)");
      grad.addColorStop(1, isLongBall ? "rgba(0,229,255,0.62)" : "rgba(255,255,255,0.38)");
      ctx.strokeStyle = grad;
      ctx.lineWidth = isLongBall ? br * 1.15 : br * 0.8;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(trailGround.x, trailGround.y - lift * 0.45);
      ctx.lineTo(ballPos.x, ballPos.y);
      ctx.stroke();
      ctx.restore();
    }

    ctx.save();
    ctx.globalAlpha = isLongBall ? 0.22 : 0.3;
    ctx.fillStyle = "#000000";
    ctx.beginPath();
    ctx.ellipse(ballGround.x, ballGround.y + br * 0.55, br * 1.35, br * 0.45, -0.1, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.shadowColor = isLongBall ? "#00e5ff" : "#ffffff";
    ctx.shadowBlur = isLongBall ? 18 : 10;
    ctx.fillStyle = "#ffffff";
    ctx.strokeStyle = isLongBall ? "#00e5ff" : "#222";
    ctx.lineWidth = isLongBall ? 2.5 : 1.5;
    ctx.beginPath();
    ctx.arc(ballPos.x, ballPos.y, br, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = "rgba(0,0,0,0.42)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(ballPos.x, ballPos.y, br * 0.58, 0.2, Math.PI * 1.25);
    ctx.stroke();
    ctx.restore();
  }, [frame, playerTeam, aiTeamColor, aiTeamSecondaryColor, pendingCommands, selectedPlayerId, passTargetMode, passOriginPos, phase, isVertical, buildTileMap]);

  const handleClick = useCallback((e: MouseEvent<HTMLCanvasElement>) => {
    if (phase !== "planning") return;
    const pos = canvasToPitch(e.clientX, e.clientY);
    const selectableTeam = activePlanningTeam ?? "player";

    if (frame) {
      for (const p of frame.players) {
        const isGK = p.role === "goalkeeper";
        const hitR = PLAYER_RADIUS + (isGK ? 4 : 2) + 8;
        const d = Math.sqrt((p.position.x - pos.x) ** 2 + (p.position.y - pos.y) ** 2);
        if (d < hitR && p.teamId === selectableTeam) {
          onPlayerClick(p.id, pos);
          return;
        }
      }
    }

    if (!selectedPlayerId || !frame) return;
    const selPlayer = frame.players.find((p) => p.id === selectedPlayerId);
    if (!selPlayer) return;
    if (selPlayer.teamId !== selectableTeam) return;

    const clickedCol = clamp(Math.floor(pos.x / TILE_W), 0, GRID_COLS - 1);
    const clickedRow = clamp(Math.floor(pos.y / TILE_H), 0, GRID_ROWS - 1);
    const selTile = posToTile(selPlayer.position);

    if (clickedCol === selTile.col && clickedRow === selTile.row) return;

    if (!passTargetMode) {
      const isGK = selPlayer.role === "goalkeeper";
      const range = selPlayer.tileRange;
      const reachable = getReachableTiles(selTile.col, selTile.row, range, isGK, selPlayer.teamId);
      const isReachable = reachable.some((t) => t.col === clickedCol && t.row === clickedRow);
      if (!isReachable) return;
    }

    const occupant = frame.players.find((p) => {
      const t = posToTile(p.position);
      return t.col === clickedCol && t.row === clickedRow;
    });

    if (occupant?.teamId === selectableTeam && occupant.id !== selectedPlayerId) return;

    const isEnemy = occupant?.teamId !== undefined && occupant.teamId !== selectableTeam;
    const tileCenter = tileToPos(clickedCol, clickedRow);
    onTileClick(tileCenter, isEnemy);
  }, [phase, frame, selectedPlayerId, canvasToPitch, onPlayerClick, onTileClick, passTargetMode, activePlanningTeam]);

  return (
    <canvas
      ref={canvasRef}
      width={isVertical ? PITCH_HEIGHT : PITCH_WIDTH}
      height={isVertical ? PITCH_WIDTH : PITCH_HEIGHT}
      className="w-full h-full cursor-pointer rounded-lg"
      style={{ imageRendering: "auto", background: "#08111d" }}
      onClick={handleClick}
    />
  );
}
