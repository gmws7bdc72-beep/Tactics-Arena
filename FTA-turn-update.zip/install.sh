#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/workspace"
patch="$(cd "$(dirname "$0")" && pwd)/update.patch"
git apply --check "$patch" || { echo 'Update did not match the current files; nothing was changed.'; exit 1; }
backup="$HOME/fta-before-turn-update-$(date +%Y%m%d-%H%M%S).tar.gz"
tar -czf "$backup" artifacts/fta-game/src/engine/{types.ts,simulation.ts,constants.ts,ai.ts} artifacts/fta-game/src/components/MechanicPad.tsx artifacts/fta-game/src/pages/{Match.tsx,OnlineMatch.tsx}
git apply "$patch"
echo "Update installed. Previous files saved at $backup"
echo 'Run the game, then republish when ready.'
